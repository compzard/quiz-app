package com.example.android.quizapp;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

/**
 * This app is a Quiz App.
 */
public class MainActivity extends AppCompatActivity {
    int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    // This function is called when the SUBMIT
    public void submitQuiz(View view) {
        // Find User's name
        EditText nameField = findViewById(R.id.name_field);
        String name = nameField.getText().toString();
        // This checks if the name field is empty.
        boolean nameFilled = name.isEmpty();

        // Finds out if if user checked ikeja.
        CheckBox ikejaCheckbox = findViewById(R.id.ikeja);
        boolean isIkeja = ikejaCheckbox.isChecked();

        // Finds out if user checked Surulere.
        CheckBox surulereCheckbox = findViewById(R.id.surulere);
        boolean isSurulere = surulereCheckbox.isChecked();

        // Checks the user got the number 1 Question
        RadioButton nigeriaRadio = findViewById(R.id.nigeria);
        boolean isNigeria = nigeriaRadio.isChecked();

        // Checks the user got the number 2 Question
        RadioButton abujaRadio = findViewById(R.id.abuja);
        boolean isAbuja = abujaRadio.isChecked();

        // Checks the user got the number 3 Question
        RadioButton buhariRadio = findViewById(R.id.buhari);
        boolean isBuhari = buhariRadio.isChecked();

        // Checks the user got the number 5 Question
        RadioButton androidRadio = findViewById(R.id.andriod);
        boolean isAndroid = androidRadio.isChecked();

        int checkboxMark = checkboxScore(isIkeja, isSurulere);
        int capitalRadiosMark = radioMark(isAbuja);
        int countryRadioMark = radioMark(isNigeria);
        int capitalRadioMark = radioMark(isBuhari);
        int androidRadioMark = radioMark(isAndroid);
        if (nameFilled) {
            // Show an error message as a toast.
            Toast.makeText(this, "Your Name is required.", Toast.LENGTH_SHORT).show();
        } else {
            int totalScore = checkboxMark + capitalRadiosMark + countryRadioMark + capitalRadioMark + androidRadioMark;
            displayMessage(totalScore, name);
        }
    }

    /**
     * @param correctAnswer adds 20 marks to the total score of the user if the radio button is clicked
     **/
    private int radioMark(boolean correctAnswer) {
        int correctAnswerScore = 0;
        if (correctAnswer) {
            correctAnswerScore += 20;
        }

        return correctAnswerScore + score;
    }

    /**
     * Calculate the price of the order.
     *
     * @param yesSurulere is whether or not Surulere was clicked.
     * @param yesIkeja   is whether or not ikeja was clicked.
     * @return the score for programming language if user got the answers else, the score is zero.
     */
    private int checkboxScore(boolean yesIkeja, boolean yesSurulere) {
        int programmingLangScore = 0;
        if (yesIkeja && yesSurulere) {
            programmingLangScore += 20;
        } else if (yesIkeja) {
            programmingLangScore += 10;
        } else if (yesSurulere) {
            programmingLangScore += 10;
        } else {
            programmingLangScore = 0;
        }

        return programmingLangScore + score;

    }

    /**
     * This method displays the given text on the screen.
     */
    @SuppressLint("SetTextI18n")
    private void displayMessage(int score, String name) {
        TextView scoreNumber = findViewById(R.id.your_score);
        // Show user's score as a toast.
        Toast.makeText(this, name + ", your total score is: " + score, Toast.LENGTH_SHORT).show();
        scoreNumber.setText(name + ", your total score is: " + score);
    }
}
